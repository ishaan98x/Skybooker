package com.example.flightbookingapp2;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.flightbookingapp2.HomeActivity;
import com.example.flightbookingapp2.R;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class SignInActivity extends AppCompatActivity {

    private ImageView btnBack;
    private MaterialButton btnSignIn;
    private TextView textSignUp, textForgotPassword;
    private TextInputEditText editTextEmail, editTextPassword;
    
    // Firebase instances
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        // Hide action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        // Initialize Firebase
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        initializeViews();
        setupClickListeners();
        setupBackPressHandler(); // Added modern back press handler
    }

    private void initializeViews() {
        btnBack = findViewById(R.id.btnBack);
        btnSignIn = findViewById(R.id.btnSignIn);
        textSignUp = findViewById(R.id.textSignUp);
        textForgotPassword = findViewById(R.id.textForgotPassword);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPassword = findViewById(R.id.editTextPassword);
    }

    private void setupClickListeners() {
        // Back button - now uses the modern back press handler
        btnBack.setOnClickListener(v -> onBackPressed());

        // Sign In button
        btnSignIn.setOnClickListener(v -> signInUser());

        // Sign Up text
        textSignUp.setOnClickListener(v -> {
            Intent intent = new Intent(SignInActivity.this, com.example.flightbookingapp2.SignUpActivity.class);
            startActivity(intent);
            finish();
        });

        // Forgot Password text
        textForgotPassword.setOnClickListener(v -> {
            // TODO: Implement forgot password functionality
            // For now, just show a message or navigate to forgot password screen
        });
    }

    private void setupBackPressHandler() {
        // Modern way to handle back press
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                // Navigate back to WelcomeActivity when back pressed from sign in
                Intent intent = new Intent(SignInActivity.this, com.example.flightbookingapp2.WelcomeActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void signInUser() {
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        // Basic validation
        if (email.isEmpty()) {
            editTextEmail.setError("Please enter email address");
            return;
        }

        if (password.isEmpty()) {
            editTextPassword.setError("Please enter password");
            return;
        }

        // Show loading state
        btnSignIn.setEnabled(false);
        btnSignIn.setText("Signing In...");

        // Firebase Authentication
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    btnSignIn.setEnabled(true);
                    btnSignIn.setText("Sign In");
                    
                    if (task.isSuccessful()) {
                        // Sign in success, update UI with the signed-in user's information
                        FirebaseUser user = mAuth.getCurrentUser();
                        Toast.makeText(SignInActivity.this, "Authentication successful!", Toast.LENGTH_SHORT).show();
                        
                        // Navigate to HomeActivity
                        Intent intent = new Intent(SignInActivity.this, HomeActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        // If sign in fails, display a message to the user.
                        Toast.makeText(SignInActivity.this, "Authentication failed: " + 
                                task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    // Remove the old onBackPressed method since we're using the modern approach
    // @Override
    // public void onBackPressed() {
    //     super.onBackPressed();
    // }
}