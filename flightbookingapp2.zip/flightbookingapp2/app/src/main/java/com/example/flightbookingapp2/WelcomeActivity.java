package com.example.flightbookingapp2;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.example.flightbookingapp2.HomeActivity;
import com.google.android.material.button.MaterialButton;

public class WelcomeActivity extends AppCompatActivity {

    private MaterialButton btnGetStarted, btnSignIn;
    private TextView textSignUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        // Hide action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        initializeViews();
        setupClickListeners();
        setupBackPressHandler();
    }

    private void initializeViews() {
        btnGetStarted = findViewById(R.id.btnGetStarted);
        btnSignIn = findViewById(R.id.btnSignIn);
        textSignUp = findViewById(R.id.textSignUp);
    }

    private void setupClickListeners() {
        // Get Started Button - Navigate to Home
        btnGetStarted.setOnClickListener(v -> {
            Intent intent = new Intent(WelcomeActivity.this, HomeActivity.class);
            startActivity(intent);
        });

        // Sign In Button
        btnSignIn.setOnClickListener(v -> {
            Intent intent = new Intent(WelcomeActivity.this, com.example.flightbookingapp2.SignInActivity.class);
            startActivity(intent);
        });

        // Sign Up Text
        textSignUp.setOnClickListener(v -> {
            Intent intent = new Intent(WelcomeActivity.this, com.example.flightbookingapp2.SignUpActivity.class);
            startActivity(intent);
        });
    }

    private void setupBackPressHandler() {
        // Modern way to handle back press
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                // Exit app when back pressed from welcome screen
                finishAffinity();
            }
        });
    }
}