package com.example.flightbookingapp2.models;

public class Booking {
    private String fromCity;

    private String toCity;
    private String bookingId;
    private String flightName;
    private String userName;
    private String date;
    private String price;

    // Empty constructor required for Firebase
    public Booking() {
    }

    // Constructor with parameters
    public Booking(String bookingId, String fromCity, String toCity, String userName, String date, String price) {
        this.bookingId = bookingId;
        this.fromCity = fromCity;
        this.toCity = toCity;
        this.userName = userName;
        this.date = date;
        this.price = price;
    }

    // Getters and setters
    public String getBookingId() { return bookingId; }
    public void setBookingId(String bookingId) { this.bookingId = bookingId; }

    public String getFlightName() { return flightName; }
    public void setFlightName(String flightName) { this.flightName = flightName; }

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getPrice() { return price; }
    public void setPrice(String price) { this.price = price; }
}

