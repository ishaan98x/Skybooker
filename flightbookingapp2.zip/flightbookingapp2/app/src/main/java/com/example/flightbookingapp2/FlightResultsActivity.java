package com.example.flightbookingapp2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.flightbookingapp2.models.Booking;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Random;
import java.util.UUID;

public class FlightResultsActivity extends AppCompatActivity {

    private FirebaseFirestore firestore;
    private DatabaseReference realtimeDb;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flight_results);

        TextView tvBestDeal = findViewById(R.id.tvBestDeal);
        Button btnBookNow = findViewById(R.id.btnBookNow);

        firestore = FirebaseFirestore.getInstance();
        realtimeDb = FirebaseDatabase.getInstance().getReference("bookings");
        auth = FirebaseAuth.getInstance();

        // Receive data from HomeActivity
        String fromCity = getIntent().getStringExtra("fromCity");
        String toCity = getIntent().getStringExtra("toCity");
        String date = getIntent().getStringExtra("date");
        String siteName = getIntent().getStringExtra("siteName");
        String siteUrl = getIntent().getStringExtra("siteUrl");

        // 🔹 Generate random price for display
        int bestPrice = 41000 + new Random().nextInt(3000);

        // Display best site and price
        tvBestDeal.setText("Best price found on " + siteName + " → ₹" + bestPrice);

        btnBookNow.setOnClickListener(v -> {
            // Save booking before redirect
            saveBooking(fromCity, toCity, date, String.valueOf(bestPrice));

            Toast.makeText(this, "Redirecting to " + siteName + "...", Toast.LENGTH_SHORT).show();

            // Open selected travel site
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(siteUrl));
            startActivity(browserIntent);
        });
    }

    private void saveBooking(String fromCity, String toCity, String date, String price) {
        String userId = auth.getCurrentUser() != null ? auth.getCurrentUser().getUid() : "guest";
        String bookingId = UUID.randomUUID().toString();

        Booking booking = new Booking(bookingId, fromCity, toCity, userId, date, price);

        firestore.collection("bookings").document(bookingId)
                .set(booking)
                .addOnSuccessListener(unused -> {
                    realtimeDb.child(bookingId).setValue(booking)
                            .addOnSuccessListener(aVoid ->
                                    Toast.makeText(this, "Booking saved successfully!", Toast.LENGTH_SHORT).show())
                            .addOnFailureListener(e ->
                                    Toast.makeText(this, "Realtime DB error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Firestore error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}
