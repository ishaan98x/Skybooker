package com.example.flightbookingapp2;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Random;

public class HomeActivity extends AppCompatActivity {

    Spinner fromCityDropdown, toCityDropdown;
    TextView tvDepartureDate;
    Button btnSearchFlights;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        fromCityDropdown = findViewById(R.id.fromCityDropdown);
        toCityDropdown = findViewById(R.id.toCityDropdown);
        tvDepartureDate = findViewById(R.id.tvDepartureDate);
        btnSearchFlights = findViewById(R.id.btnSearchFlights);

        db = FirebaseFirestore.getInstance();

        // Load cities from Firestore
        loadCitiesFromFirestore();

        // Open calendar on click
        tvDepartureDate.setOnClickListener(v -> {
            final Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    HomeActivity.this,
                    (view, selectedYear, selectedMonth, selectedDay) -> {
                        String date = selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear;
                        tvDepartureDate.setText(date);
                    },
                    year, month, day
            );

            datePickerDialog.show();
        });

        // Search button click
        btnSearchFlights.setOnClickListener(v -> {
            String fromCity = fromCityDropdown.getSelectedItem().toString();
            String toCity = toCityDropdown.getSelectedItem().toString();
            String date = tvDepartureDate.getText().toString();

            if (fromCity.equals(toCity)) {
                Toast.makeText(this, "From and To cities cannot be same!", Toast.LENGTH_SHORT).show();
                return;
            }

            if (date.equals("Select date")) {
                Toast.makeText(this, "Please select a date!", Toast.LENGTH_SHORT).show();
                return;
            }

            Toast.makeText(this, "Searching for flights...", Toast.LENGTH_SHORT).show();

            // 🔹 List of travel websites
            String[] siteNames = {"MakeMyTrip", "Expedia", "Skyscanner", "Cleartrip", "Goibibo"};
            String[] siteUrls = {
                    "https://www.makemytrip.com/flights",
                    "https://www.expedia.co.in/Flights",
                    "https://www.skyscanner.co.in/",
                    "https://www.cleartrip.com/flights",
                    "https://www.goibibo.com/flights/"
            };

            // 🔹 Randomly select one website (simulate best price)
            int randomIndex = new Random().nextInt(siteNames.length);

            // 🔹 Send data to FlightResultsActivity
            Intent intent = new Intent(HomeActivity.this, FlightResultsActivity.class);
            intent.putExtra("fromCity", fromCity);
            intent.putExtra("toCity", toCity);
            intent.putExtra("date", date);
            intent.putExtra("siteName", siteNames[randomIndex]);
            intent.putExtra("siteUrl", siteUrls[randomIndex]);
            startActivity(intent);
        });
    }

    private void loadCitiesFromFirestore() {
        db.collection("flights")
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    HashSet<String> cities = new HashSet<>();
                    for (DocumentSnapshot doc : querySnapshot) {
                        String fromCity = doc.getString("fromcity");
                        String toCity = doc.getString("tocity");
                        if (fromCity != null) cities.add(fromCity);
                        if (toCity != null) cities.add(toCity);
                    }

                    ArrayList<String> cityList = new ArrayList<>(cities);
                    if (cityList.isEmpty()) {
                        Toast.makeText(this, "No cities found in database", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                            android.R.layout.simple_spinner_item, cityList);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    fromCityDropdown.setAdapter(adapter);
                    toCityDropdown.setAdapter(adapter);

                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Error loading cities: " + e.getMessage(), Toast.LENGTH_LONG).show());
    }
}
