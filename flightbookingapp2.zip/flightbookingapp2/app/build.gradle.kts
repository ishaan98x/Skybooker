plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    // Add the Google Services plugin
    id("com.google.gms.google-services")
}

android {namespace = "com.example.flightbookingapp2"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.flightbookingapp2"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    // Add buildFeatures for View Binding (optional but recommended for modern development)
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.17.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.android.material:material:1.13.0")
    implementation("androidx.constraintlayout:constraintlayout:2.2.1")

    // --- Add these lines for Firebase ---

    // 1. Import the Firebase Bill of Materials (BoM).
    // This will manage the versions of all Firebase libraries.
    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))
    // 2. Add the dependency for Firebase Authentication.
    // You no longer need to specify the version because of the BoM.
    implementation("com.google.firebase:firebase-auth")
    implementation(libs.firebase.firestore)
    implementation(libs.activity)
    implementation("com.google.firebase:firebase-database:20.3.0")

    apply(plugin = "com.google.gms.google-services")
 // Add other Firebase dependencies you might need, for example, Firestore:
    // implementation("com.google.firebase:firebase-firestore")
}
