plugins {
    // Top-level build.gradle.kts

    id("com.android.application") version "8.13.0" apply false
    id("com.android.library") version "8.13.0" apply false
    // Correct the version of the Kotlin Android plugin
    id("org.jetbrains.kotlin.android") version "2.2.21" apply false
    id("com.google.gms.google-services") version "4.4.4" apply false
}
